// // by useContext   ,   28 aug 


import React, { createContext, useContext, useState } from 'react'
import { Route, Routes, Link, NavLink, useLocation } from "react-router-dom";
import About from './Component/About'
import Home from './Component/Home'
import Contact from './Component/Contact'
import Login from './Component/Login'
import Error from './Component/Error'
import Navbar from "./Component/Navbar";
import Dashboard from "./Component/Dashboard"
import Register from "./Component/Register"
// import ProtectedRoute from "./Component/ProtectedRoute";
import './App.css'
import Completetask from "./Component/Completetask";
import Panddingtask from "./Component/Panddingtask";
import Deployedtask from "./Component/Deployedtask";
import Deferredtask from "./Component/Deferredtask";
import Progresstask from "./Component/Progresstask";
import Addnewtask from "./Component/Addnewtask";
import Taskstatus from "./Component/Taskstatus";
import Dashcopy from "./Component/Dashcopy";
export let taskcontext = createContext();

export default function App() {
    let [todos, settodos] = useState([])
    let location = useLocation();
    let addtask = (a) => {
        settodos([...todos, a])
    }
    return (
        <taskcontext.Provider value={{ todos, addtask }}>
            {!location.pathname.includes("dashboard") && <Navbar />}
            <Routes>
                <Route path="/" element={<Home />}></Route>
                <Route path="/dashboard" element={<Dashboard />}>
                    <Route path='/dashboard/dashcopy' element={<Dashcopy />}> </Route>
                    <Route path='/dashboard/completedtask' element={<Completetask />}> </Route>
                    <Route path='/dashboard/panddingtask' element={<Panddingtask />}> </Route>
                    <Route path='/dashboard/progresstask' element={<Progresstask />}> </Route>
                    <Route path='/dashboard/deployedtask' element={<Deployedtask />}> </Route>
                    <Route path='/dashboard/deferredtask' element={<Deferredtask />}> </Route>
                    <Route path='/dashboard/addnewtask' element={<Addnewtask />}> </Route>
                    <Route path='/dashboard/taskstats' element={<Taskstatus />}> </Route>
                </Route>
                <Route path="/about" element={<About />}></Route>
                <Route path="/contact" element={<Contact />}></Route>
                <Route path="/login" element={<Login />}></Route>
                <Route path="/*" element={<Error />}></Route>
                <Route path="/register" element={<Register />}></Route>
            </Routes>
        </taskcontext.Provider>
    )
}









// // task 22 aug  ,, whiz

// import React from "react";
// import { Route, Routes, Link, NavLink, useLocation } from "react-router-dom";
// import About from './Component/About'
// import Home from './Component/Home'
// import Contact from './Component/Contact'
// import Login from './Component/Login'
// import Error from './Component/Error'
// import Navbar from "./Component/Navbar";
// import Dashboard from "./Component/Dashboard"
// import Register from "./Component/Register"
// // import ProtectedRoute from "./Component/ProtectedRoute";
// import './App.css'
// import Completetask from "./Component/Completetask";
// import Panddingtask from "./Component/Panddingtask";
// import Deployedtask from "./Component/Deployedtask";
// import Deferredtask from "./Component/Deferredtask";
// import Progresstask from "./Component/Progresstask";
// import Addnewtask from "./Component/Addnewtask";
// import Taskstatus from "./Component/Taskstatus";
// import Dashcopy from "./Component/Dashcopy";
// export default function App() {
//   let location = useLocation();
//   console.log(location)
//   return (
//     <div>
//       {!location.pathname.includes("dashboard") && <Navbar />}
//       <Routes>
//         <Route path="/" element={<Home />}></Route>
//         <Route path="/dashboard" element={<Dashboard />}>
//          <Route path='/dashboard/dashcopy' element={<Dashcopy />}> </Route>
//           <Route path='/dashboard/completedtask' element={<Completetask />}> </Route>
//           <Route path='/dashboard/panddingtask' element={<Panddingtask />}> </Route>
//           <Route path='/dashboard/progresstask' element={<Progresstask />}> </Route>
//           <Route path='/dashboard/deployedtask' element={<Deployedtask />}> </Route>
//           <Route path='/dashboard/deferredtask' element={<Deferredtask />}> </Route>
//           <Route path='/dashboard/addnewtask' element={<Addnewtask />}> </Route>
//           <Route path='/dashboard/taskstats' element={<Taskstatus />}> </Route>
//         </Route>
//         <Route path="/about" element={<About />}></Route>
//         <Route path="/contact" element={<Contact />}></Route>
//         <Route path="/login" element={<Login />}></Route>
//         <Route path="/*" element={<Error />}></Route>
//         <Route path="/register" element={<Register />}></Route>
//       </Routes>
//     </div>
//   )
// }











// // task 22 aug 

// import React from "react";
// import { Route, Routes, Link, NavLink } from "react-router-dom";
// import About from './Component/About'
// import Home from './Component/Home'
// import Contact from './Component/Contact'
// import Login from './Component/Login'
// import Error from './Component/Error'
// import Navbar from "./Component/Navbar";
// import Dashboard from "./Component/Dashboard"
// import Register from "./Component/Register"
// import ProtectedRoute from "./Component/ProtectedRoute";
// import './App.css'
// export default function App() {
//   return (
//     <div>
//       <Navbar />
//       <Routes>
//         <Route path="/" element={<Home />}></Route>
//         <Route path="dashboard" element={<ProtectedRoute Child={<Dashboard />} />}>
//           {/* <Route path="/dashboard/about" element={<Dashboard />}></Route> */}
//           {/* <Route path="/dashboard/contact" element={<Contact />}></Route> */}
//         </Route>
//         <Route path="/about" element={<About />}></Route>
//         <Route path="/contact" element={<Contact />}></Route>
//         <Route path="/login" element={<Login />}></Route>
//         <Route path="/*" element={<Error />}></Route>
//         <Route path="/register" element={<Register />}></Route>
//       </Routes>
//     </div>
//   )
// }










// // to do list
// import React from "react";
// import List from "./Component/List";

// function App() {
//   return (
//     <>
//       <List />
//     </>
//   )
// }
// export default App;







// main 


// import List from "./Component/List";
// import Temp from "./Component/Temp";
// // import './Temp.css'

// function App() {
//   return (
//     <>
// <List/>  

//       {/* <Temp detail={{ name: "Men Casual Shoes", mrp: "$200", price: "$150", about_item: "Step up your style game with the Louis Philippe Lace-Up Shoes in rich brown leather. These formal shoes offer a sleek, solid design perfect for sophisticated occasions." }}
//       image={{shoe:"https://www.shoetree.io/cdn/shop/files/AW22-LBL1232-WOOD_0_3ec869fd-138e-4bee-b266-ec90ac857484.jpg?v=1736849583" }}/>
//      <Temp detail={{ name: "Men Branded T-Shirt", mrp: "$45", price: "$30", about_item: "Step up your style game with the Louis Philippe Lace-Up Shoes in rich brown leather. These formal shoes offer a sleek, solid design perfect for sophisticated occasions." }}
//       image={{shoe:"https://www.yourprint.in/new-admin-ajax.php?action=resize_outer_image&cfcache=all&url=med-s3/d-i-o/Tshirts/Men/tshirt_hs_men_pat_d48_o.jpg&resizeTo=600" }}/>
//  <Temp detail={{ name: "Men Casual Jeans", mrp: "$80", price: "$55", about_item: "Step up your style game with the Louis Philippe Lace-Up Shoes in rich brown leather. These formal shoes offer a sleek, solid design perfect for sophisticated occasions." }}
//   image={{shoe:"https://redtape.com/cdn/shop/products/1-800x800_85be929b-84c0-4553-b358-e4c19f9e310b.jpg?v=1750057762" }}/> */}
// </>
//   )
// }

// export default App;




// by prompt  1


// import React, { Component } from 'react'
// import About from './Component/About'
// // import './App.css'
// import Card from './Component/Card'
// import Temp from './Component/Temp'
// import Form from './Component/Form'
// import './Temp.css'
// export default class App extends Component {
//   constructor(props) {
//     super(props)

//     this.state = {
//       show: true
//     }
//   }

//   render() {
//     let { show } = this.state;
//     let hide = () => {
//       this.setState({ show: false })
//     }
//     return (
//       <>
//         {show && <About title="hello" show={show} hide={hide} />}
//             {/* <Form /> */}
//         <Temp name={"Men Casual Jeans"} mrp={"80"} price={"55"} about_item={"Step up your style game with the Louis Philippe Lace-Up Shoes in rich brown leather. These formal shoes offer a sleek, solid design perfect for sophisticated occasions."}
//           shoe={"https://redtape.com/cdn/shop/products/1-800x800_85be929b-84c0-4553-b358-e4c19f9e310b.jpg?v=1750057762"} />

//         {/* 
//         <Temp detail={{ name: "Men Casual Jeans", mrp: "$80", price: "$55", about_item: "Step up your style game with the Louis Philippe Lace-Up Shoes in rich brown leather. These formal shoes offer a sleek, solid design perfect for sophisticated occasions." }}
//           image={{ shoe: "https://redtape.com/cdn/shop/products/1-800x800_85be929b-84c0-4553-b358-e4c19f9e310b.jpg?v=1750057762" }} />

//         <Card title={"hello"} description={"hllllllllll"} img={"https://rukminim2.flixcart.com/image/240/240/xif0q/smartwatch/5/v/s/-original-imagxrhetgfuebnn.jpeg?q=60"} /> */}
//       </>
//     )
//   }
// }





// by sir form 




// import React, { Component } from 'react'
// import About from './Component/About'
// import './Temp.css'
// import Temp from './Component/Temp'
// //  import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
// //  import '../node_modules/bootstrap/dist/js/bootstrap.bundle.min.js'
// import Form from './Component/Form.jsx'
// export default class App extends Component {
//   constructor(props) {
//     super(props)
//     this.state = {
//       data: []
//     }
//   }

//   render() {
//     let { data } = this.state;
//     let adddata = (newdata) => {
//       this.setState({ data: [...data, newdata] })
//     }

//     return (
//       <>
//         <Form data={data} adddata={adddata} />
//         <About data={data} />
//       </>
//     )
//   }
// }


