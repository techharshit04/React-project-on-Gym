
export default function Error () {
    return (
        <div>
            <h5>console.error();
            </h5>
        </div>
    )
}