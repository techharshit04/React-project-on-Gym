import { Navigate, useNavigate } from "react-router-dom";

export default function ProtectedRoute({ child }) {
    let user = localStorage.getItem("loggedin");
    console.log(user);
    let nav = useNavigate()
    if (user == "false") {

    } else {
        return <Navigate to="/login" />
    }
    return (
        <div>
            {child}
        </div>
    )
}