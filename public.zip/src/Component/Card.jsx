import React from 'react'
 
export default function Card({ img, title, description }) {
    return (
        <div className='card' >
            <img src={img} alt="" />
            <p className='title'>{title}</p>
            <p>{description}</p>
            <button>show details</button>
        </div>
    )
}
 
