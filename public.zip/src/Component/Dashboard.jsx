// // by useContext   ,   28 aug 



import { NavLink, Outlet } from "react-router-dom";

function Dashboard() {
  return (
    <div className=" text-white flex ">
      <div className="flex">
        <div className="bg-blue-700 flex flex-col justify-center w-100 p-10 fixed">
          <h2 className="text-4xl font-bold"><i class="fa-solid fa-list-check"></i> Task Manager</h2>
          <div className="flex flex-col w-full text-2xl h-137 mt-15">
            <NavLink to="/dashboard/dashcopy" ><i class="fa-solid fa-box"></i> Dashboard</NavLink>
            <NavLink to="/dashboard/completedtask" className="mt-6" ><i class="fa-solid fa-list-check"></i> Completed Task</NavLink>
            <NavLink to="/dashboard/panddingtask" className="mt-6"><i class="fa-solid fa-clock"></i> Pending Task</NavLink>
            <NavLink to="/dashboard/progresstask" className="mt-6"><i class="fa-solid fa-spinner"></i> Progress Task</NavLink>
            <NavLink to="/dashboard/deployedtask" className="mt-6"><i class="fa-solid fa-shield-halved"></i> Deployed Task</NavLink>
            <NavLink to="/dashboard/deferredtask" className="mt-6"><i class="fa-solid fa-calendar"></i> Deferred Task</NavLink>
            <NavLink to="/dashboard/addnewtask" className="mt-6"><i class="fa-solid fa-plus"></i> Add New Task</NavLink>
            <NavLink to="/dashboard/taskstats" className="mt-6"><i class="fa-solid fa-arrow-trend-up"></i> Task Status</NavLink>
          </div>
        </div>
      </div>
      <div>
        <Outlet />
      </div>
    </div>
  )
}

export default Dashboard;