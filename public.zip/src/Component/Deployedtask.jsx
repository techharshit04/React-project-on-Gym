
// // by useContext   ,   28 aug 


import { NavLink } from "react-router-dom";
import React, { useContext } from 'react'
import { taskcontext } from '../App';

function Deployedtask() {
  let { todos } = useContext(taskcontext)

  return (
    <div className="  w-300 ml-80 text-black mt-7 flex flex-col justify-center items-center ">
      <div>
        <h2 className=" flex w-full justify-center items-center text-2xl font-bold">Deployed Task</h2>
      </div>
      <div className='flex justify-around w-full p-20 flex-wrap h-full'>
        {todos.filter((a) => { return a.status == "Deployed" }).map((v, i) => (
            <div className=' p-9 mt-12 rounded-xl w-70 h-full flex flex-col justify-center items-center inset-shadow-sm inset-shadow-blue-900'>
              <div className='bg-green-200 p-6 w-full rounded text-2xl font-semibold flex justify-center items-center'>
                {v.title}
              </div>
              <div className='mt-4 w-full flex justify-center'>{v.description}</div>
              <div className='flex justify-between w-full mt-5'>
                <div>
                  <h4 className='font-bold'>Start Date</h4>
                  <h4>{v.startdate}</h4></div>
                <div>
                  <h4 className='font-bold'>End Date</h4>
                  <h4>{v.enddate}</h4>
                </div>
              </div>
              <div className='mt-5 flex justify-around items-center w-full'>
                <div className='bg-green-200 p-2 w-40 flex rounded-xl text-green-900 font-bold justify-center items-center'>{v.status}</div>
                <div>{v.priority}</div>
              </div>
            </div>
          ) )}
      </div>
      <div className="h-full flex justify-center items-center">
        <h3 >no task found  <NavLink className="text-blue-800 hover:underline" to="/dashboard/addnewtask">Add new task</NavLink></h3>
      </div>

    </div>

  )
}

export default Deployedtask;
















// import { NavLink } from "react-router-dom";

// function Deployedtask() {
//   return (
//     <div className=" w-270 h-150 text-black">
//       <div>
//         <h2 className=" mt-10 flex justify-center items-center text-2xl font-bold">Deployed Task</h2>
//       </div>
//       <div className="h-full flex justify-center items-center">
//         <h3 >no task found  <NavLink className="text-blue-800 hover:underline" to="/dashboard/addnewtask">Add new task</NavLink></h3>
//       </div>

//     </div>

//   )
// }

// export default Deployedtask;