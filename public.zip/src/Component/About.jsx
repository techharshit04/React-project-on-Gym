// import React, { Component } from 'react'
// // import Card from './Card';
// import Temp from './Temp';
// import '../Temp.css'
// class About extends Component {
//     constructor(props) {
//         super(props)
//         this.state = {
//             sum: 0, data: []
//         }
//     }
//     render() {
//         let { data } = this.state;
//         let { show, hide } = this.props;
//         let adddata = () => {
//             let a = prompt("enter title");
//             let b = prompt("enter description");
//             let c = prompt("enter img url");
//             this.setState({ data: [...data, { title: a, description: b, img: c }] })
//         }
//         console.log(data)
//         // let items = data.map((a) => { return (<p>{a}</p>) })
//         // let items = data.map(a => <p>{a}</p>)
//         return (
//             <>
//                 About Component
//                 <button onClick={adddata}> add new data</button>

//                 <div className='allboxes'>
//                     {(data && data.length > 0) ? data.map((a, i) => (
//                         <Card key={i} title={a.title} description={a.description} img={a.img} />
//                     )) : "no data found"}
//                     <Temp detail={{ name: "Men Casual Jeans", mrp: "$80", price: "$55", about_item: "Step up your style game with the Louis Philippe Lace-Up Shoes in rich brown leather. These formal shoes offer a sleek, solid design perfect for sophisticated occasions." }}
//                         image={{ shoe: "https://redtape.com/cdn/shop/products/1-800x800_85be929b-84c0-4553-b358-e4c19f9e310b.jpg?v=1750057762" }} />

//                 </div>
//             </>
//         )
//     }
// }
// export default About



// by prompt  1


// import React, { Component } from 'react'
// import Card from './Card';
// import Temp from './Temp';
// import Form from './Form';
// import '../Temp.css'
// class About extends Component {
//     constructor(props) {
//         super(props)
//         this.state = {
//             sum: 0, data: []
//         }
//     }
//     render() {
//         let { data } = this.state;
//         let { show, hide } = this.props;
//         let adddata = () => {
//             let a = prompt("enter name");
//             let b = prompt("enter mrp");
//             let c = prompt("enter price");
//             let d = prompt("enter about");
//             let e = prompt("enter img url");
//             this.setState({ data: [...data, { name: a, mrp: b, price: c, about_item: d, shoe: e }] })
//         }
//         // console.log(data)
//         // let items = data.map((a) => { return (<p>{a}</p>) })
//         // let items = data.map(a => <p>{a}</p>)
//         return (
//             <div className='design'>
//                 <button onClick={adddata}> Add New Template</button>

//                 <div className='allboxes'>
//                     {(data && data.length > 0) ? data.map((a, i) => (
//                         <Temp key={i} name={a.name} mrp={a.mrp} price={a.price} about_item={a.about_item} shoe={a.shoe} />
//                     )) : "No data found"}
//                 </div>
//               <Form/>
//             </div>

//         )
//     }
// }
// export default About




// by sir form






// import React, { Component } from 'react'
// import Temp from './Temp';
// // import '../Temp.css'
// class About extends Component {
//     constructor(props) {
//         super(props)

//     }
//     render() {
//         let { data } = this.props;
//         return (
//             <>
//                 <div className='allboxes'>
//                     {(data && data.length > 0) ? data.map((a, i) => (
//                         <Temp key={i} name={a.name} mrp={a.mrp} price={a.price} about={a.about} url={a.url} />
//                     )) :""}
//                 </div>
//             </>
//         )
//     }
// }
// export default About







//   22 aug task





function About() {
    return (
        <div className="w-full flex items-center justify-center">
            <div className="text-white w-350 flex flex-col items-center justify-center p-20">
                <h5 className="text-blue-600 text-7xl font-bold">About US</h5>
                <div className=" mt-10 p-15 bg-sky-800 ">
                    <h5>Welcome to TaskWhiz, your ultimate companion for mastering productivity and organization. In today’s fast-paced world, juggling tasks, deadlines, and priorities can feel overwhelming. That’s why we created a task management solution that doesn’t just organize your to-do list but transforms the way you work and live. At TaskWhiz, our mission is simple: to empower individuals and teams to achieve more, stress less, and stay focused on what truly matters. Whether it’s personal goals, professional projects, or everyday tasks, our app is designed to provide a seamless, intuitive experience that fits effortlessly into your lifestyle.</h5>
                    <h2 className="mt-7 text-4xl font-semibold">What We Offer</h2>
                    <div className="mt-7 ">
                        <h5>1.Plan and Organize with Ease: Create tasks, set deadlines, and break down big projects into manageable steps.</h5>
                        <h5>2.Track Progress Effortlessly: Stay updated on what’s done and what needs attention with clear visual progress indicators.</h5>
                        <h5>3.Collaborate Seamlessly: Work together with your team by assigning tasks, sharing updates, and keeping everyone on the same page.</h5>
                        <h5>4.Stay Focused: With features like reminders, notifications, and priority settings, you’ll never lose track of your important tasks.</h5>
                        <h5>5.Declutter Your Workspace: Edit, archive, or delete tasks easily to keep your workflow clean and efficient.</h5>
                        <h5>We believe productivity shouldn’t be complicated. Our app simplifies the way you manage tasks, helping you reclaim your time and energy for the things that matter most. With a clean interface, customizable options, and tools built for both individuals and teams, TaskWhiz is here to support your journey toward success—one task at a time.</h5>
                        <h5>Join the thousands of users who trust TaskWhiz to organize their day, achieve their goals, and stay ahead. Let’s simplify your life and transform the way you manage tasks!</h5>
                    </div>
                </div>

            </div>
        </div>
    )
}

export default About;




