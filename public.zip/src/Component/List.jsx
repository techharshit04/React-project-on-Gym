import { Component } from "react";

export default class List extends Component {
    constructor(props) {
        super(props)
        this.state = {
            name: "", date: "", status: "", data: [], isupdated: false, isupdateid: null
        }
    }
    render() {
        let { name, data, status, date, isupdated, isupdateid } = this.state;
        let submithandler = (e) => {
            e.preventDefault();
            if (isupdated && isupdateid >= 0) {
                this.setState({
                    data: data.map((v, i) => {
                        if (i == isupdateid) {
                            return { ...v, name, date, status }
                        } else {
                            return v
                        }
                    })
                    , isupdated: false, isupdateid: null
                })
            } else {
                this.setState({ data: [...data, { name, date, status }] })
            }
            this.setState({ name: "", date: "", status: "" })
        }
        let deletehandler = (index) => {
            this.setState({ data: data.filter((a, i) => { return i != index }) })
        }
        let updatehandler = (i) => {
            this.setState({ name: data[i].name, date: data[i].date, status: data[i].status, isupdated: true, isupdateid: i })
        }

        return (
            <>
                <div className="w-full bg-teal-300 h-180 flex justify-center ">
                    <div onSubmit={submithandler} className="w-140 border h-150 m-auto rounded-xl bg-white overflow-scroll max-sm:w-50">
                        <div className=" flex justify-center mt-4 bg-black">
                            <h2 className="text-2xl text-red-500 p-3 font-bold">To Do</h2>
                        </div>
                        <div className="bg-black p-3">
                            <label htmlFor="task" className=" text-base text-white">Enter Task</label><br />
                            <input type="text" placeholder="Enter your Task" name="user" value={name} onChange={(e) => { this.setState({ name: e.target.value }) }} className=" w-130 bg-white rounded-lg p-1 max-sm:w-30" />
                            <label htmlFor="task" className=" text-base text-white">Date/Time</label><br />
                            <input type="time" name="date" value={date} onChange={(e) => { this.setState({ date: e.target.value }) }} className=" w-130 bg-white rounded-lg p-1 max-sm:w-30" />
                            <label htmlFor="task" className=" text-base text-white">Enter Status</label><br />
                            <input type="text" placeholder="Enter Status" name="user" value={status} onChange={(e) => { this.setState({ status: e.target.value }) }} className=" w-130 bg-white rounded-lg p-1 max-sm:w-30" />

                        </div>
                        <div className="flex justify-center bg-black p-3">
                            <button type="submit" onClick={submithandler} className=" rounded-lg bg-violet-400 px-2 py-1 hover:bg-violet-950 text-white">{isupdated ? "Update" : "Submit"}</button>
                        </div>
                        <div className="cards">
                            {data?.map((v, i) => (
                                <div className=" border-b mb-3 flex w-full justify-between gap-5 p-2 bg-sky-100 text-xl">
                                    <p className="text-sm flex align-center justify-center">Task : {v.name}</p>
                                    <p className="text-sm flex align-center justify-center">Time : {v.date}</p>
                                    <p className="text-sm flex align-center justify-center">Status : {v.status}</p>
                                    <div className="text-xl flex gap-3 cursor-pointer">
                                        <button onClick={() => { updatehandler(i) }}>U✍️</button>
                                        <button onClick={() => { deletehandler(i) }}>D❌</button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </>
        )
    }
}
