import React from 'react'

function Form() {
    return (
        <div className="form">
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                <h2>Make Your Card</h2>
                <h5>Fill the detail to make your Card</h5>
            </div>
            <div className='input'>
                <label htmlFor="name_prdct">Name of product :</label>
                <input type="text" />
            </div>
            <div className='input'>
                <label htmlFor="mrp">MRP of product :</label>
                <input type="number" />
            </div>
            <div className='input'>
                <label htmlFor="price">Price of product :</label>
                <input type="number" />
            </div>
            <div className='input'>
                <label htmlFor="about">About your product :</label>
                <input type="text" />
            </div>
            <div className='input'>
                <label htmlFor="image">URL of product :</label>
                <input type="url" />
            </div>
            <button >Submit</button>
        </div>

    )
}
export default Form;




// // by  sir form 





// import React, { Component } from 'react'

// export default class Form extends Component {
//     render() {
//         let { data, adddata } = this.props;
//         let submithandler = (e) => {
//             e.preventDefault();
//             let newdata = {
//                 name: e.target.name.value,
//                 mrp: e.target.mrp.value,
//                 price: e.target.price.value,
//                 about: e.target.about.value,
//                 url: e.target.url.value,
//             }
//             adddata(newdata)
//         }
//         return (
//             <form className='form'  onSubmit={submithandler}>
//                 <div class="mb-3" >
//                     <label class="form-label">Name</label>
//                     <input type="text" class="form-control" name="name" />
//                 </div>
//                 <div class="mb-3">
//                     <label class="form-label">MRP</label>
//                     <input type="number" class="form-control" name="mrp" />
//                 </div>
//                 <div class="mb-3">
//                     <label class="form-label">Price</label>
//                     <input type="number" class="form-control" name="price" />
//                 </div>
//                 <div class="mb-3">
//                     <label class="form-label">About</label>
//                     <input type="text" class="form-control" name="about" />
//                 </div>
//                 <div class="mb-3">
//                     <label class="form-label">URL</label>
//                     <textarea type="url" class="form-control" row={10} col={20} name="url" />
//                 </div>

//                 <button type="submit" class="btn btn-primary">Submit</button>
//             </form>
//         )
//     }
// }

