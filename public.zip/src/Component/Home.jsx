function Home() {
    return (
        <div className="w-full flex bg-blue-50 flex-col items-center justify-center p-10 ">
            <div className="w-full flex justify-around items-center mt-30" >
                <div className="w-130">
                    <h2 className="text-5xl font-semibold text-blue-700">Task Manager</h2>
                    <h4 className="text-2xl mt-4 font-semibold  text-indigo-700">Simplify Your Workday with Smart Task Management.</h4>
                    <h5 className="mt-3">Plan, organize, and execute tasks effortlessly with our intuitive tools—set priorities, track progress, and meet deadlines seamlessly.</h5>
                    <button className=" p-1 mt-3 rounded bg-blue-700 text-white w-40">Get Started</button>
                </div>
                <div>
                    <img src="/pic1.png" alt="" className="w-130" />
                </div>
            </div>
            <div className="flex justify-around mt-20 w-full animate-pulse">
                <div className="flex flex-col items-center">
                    <h2 className="text-5xl font-semibold  text-indigo-700">+5,200</h2>
                    <h5 className="mt-2">Happy Users</h5>
                </div>
                <div className="flex flex-col items-center">
                    <h2 className="text-5xl font-semibold  text-indigo-700">+4,500</h2>
                    <h5 className="mt-2">Paid Users</h5>
                </div>
                <div className="flex flex-col items-center">
                    <h2 className="text-5xl font-semibold  text-indigo-700">+10,000</h2>
                    <h5 className="mt-2">Viewers</h5>
                </div>
                <div className="flex flex-col items-center">
                    <h2 className="text-5xl font-semibold  text-indigo-700">+15,200</h2>
                    <h5 className="mt-2">Total task</h5>
                </div>
            </div>
            <div className="flex justify-evenly w-full items-center mt-20">
                <div className="w-130">
                    <h2 className="text-indigo-700 text-5xl font-semibold">Create and Manage Tasks Effortlessly</h2>
                    <h5 className="mt-3 ">Add tasks with just a few clicks, assign deadlines, set priorities, and track progress in real time.</h5>
                </div>
                <div>
                    <img src="https://static.vecteezy.com/system/resources/thumbnails/022/451/232/small_2x/notepad-with-pencil-icon-3d-illustration-png.png" alt="" className="w-120 h-120" />
                </div>
            </div>
            <div className="flex justify-evenly w-full items-center mt-20 animate-pulse hover:animate-none">
                <div>
                    <img src="/pic2.png" alt="" className="w-120 h-120" />
                </div>
                <div className="w-130">
                    <h2 className="text-indigo-700 text-5xl font-semibold">Read and Stay on Top of Every Task</h2>
                    <h5 className="mt-3">Quickly review task details, deadlines, and priorities in one organized view.</h5>
                </div>
            </div>
            <div className="flex justify-evenly w-full items-center mt-20">
                <div className="w-130">
                    <h2 className="text-indigo-700 text-5xl font-semibold">Check Tasks with Ease</h2>
                    <h5 className="mt-3">Track progress effortlessly by marking completed tasks and reviewing pending ones..</h5>
                </div>
                <div>
                    <img src="/pic3.png" alt="" className="w-120 h-120" />
                </div>
            </div>
            <div className="flex justify-evenly w-full items-center mt-20">
                <div>
                    <img src="https://img.icons8.com/?size=160&id=nqj9MYqBSwBG&format=png" alt="" className="w-120 h-120" />
                </div>
                <div className="w-130">
                    <h2 className="text-indigo-700 text-5xl font-semibold">Delete Tasks with Confidence</h2>
                    <h5 className="mt-3">Easily remove tasks you no longer need, keeping your workspace clutter-free.</h5>
                </div>
            </div>
            <div className="flex justify-evenly w-full items-center mt-20">
                <div className="w-130">
                    <h2 className="text-indigo-700 text-5xl font-semibold">Pin Tasks for Quick Access</h2>
                    <h5 className="mt-3">Keep your most important tasks front and center by pinning them to the top.</h5>
                </div>
                <div>
                    <img src="/pic4.png" alt="" className="w-120 h-120" />
                </div>
            </div>
            <div className="mt-35">
                <h2 className="text-5xl font-bold text-indigo-700">Customer Review</h2>
            </div>
            <div className="text-white bg-blue-900 p-10 mt-20 animate-pulse hover:animate-none">
                <h5>This task manager app is a game-changer! It’s incredibly easy to use, and the intuitive design helps me plan, organize, and track tasks effortlessly. I love the ability to set priorities, deadlines, and reminders. It’s perfect for staying productive and ensuring nothing gets overlooked. Highly recommend it to everyone!</h5>
                <h3 className="font-bold mt-3">by JENY</h3>
                <h5 className="font-bold text-yellow-500 mt-2"><span className="text-white">4.5</span> <i class="fa-solid fa-star"></i> <i class="fa-solid fa-star"></i> <i class="fa-solid fa-star"></i> <i class="fa-solid fa-star"></i> </h5>
            </div>
            <div className="text-white bg-blue-900 p-10 mt-10 animate-pulse hover:animate-none">
                <h5>This app has made managing my daily tasks so much easier! The clean interface and helpful features like reminders and progress tracking keep me on top of everything. It’s reliable, efficient, and customizable to suit my needs. A must-have tool for staying organized and productive!</h5>
                <h3 className="font-bold mt-3">by Samantha K</h3>
                <h5 className="font-bold text-yellow-500 mt-2"><span className="text-white">4.5</span> <i class="fa-solid fa-star"></i> <i class="fa-solid fa-star"></i> <i class="fa-solid fa-star"></i> <i class="fa-solid fa-star"></i> </h5>
            </div>
            <div className="text-white bg-blue-900 p-10 mt-10 animate-pulse hover:animate-none">
                <h5>A fantastic tool for staying organized! The ability to create, prioritize, and track tasks is seamless. It’s perfect for both personal and work use, and the reminders ensure I never miss a deadline. Highly satisfied with this app!</h5>
                <h3 className="font-bold mt-3">by Priya Sharma</h3>
                <h5 className="font-bold text-yellow-500 mt-2"><span className="text-white">4.5</span> <i class="fa-solid fa-star"></i> <i class="fa-solid fa-star"></i> <i class="fa-solid fa-star"></i> <i class="fa-solid fa-star"></i> </h5>
            </div>
            <div className="text-white bg-blue-900 p-10 mt-10 animate-pulse hover:animate-none">
                <h5>This task manager simplifies everything! I love how I can easily manage my schedule, set deadlines, and check off completed tasks. It’s user-friendly, efficient, and keeps me productive throughout the day. Definitely worth using</h5>
                <h3 className="font-bold mt-3">by Emily Green</h3>
                <h5 className="font-bold text-yellow-500 mt-2"><span className="text-white">4.5</span> <i class="fa-solid fa-star"></i> <i class="fa-solid fa-star"></i> <i class="fa-solid fa-star"></i> <i class="fa-solid fa-star"></i> </h5>
            </div>
            <div className="flex mt-20 flex-col w-full items-center justify-center">
                <h2 className="text-5xl font-bold">Join Our News Letter</h2>
                <h4 className="text-2xl font-semibold mt-5">Signup for our email newspaper to get updates and more</h4>
                <input type="text" className="border-2 p-1 mt-6 w-200" />
                <div>
                    <button className="mt-7 bg-blue-700 text-white p-2 w-30 rounded font-semibold">Subscribe</button>
                </div>
            </div>
            <div className="flex w-380 justify-around items-center mt-20 bg-black text-white p-10">
                <div className="flex w-80 justify-between ">
                    <div className="flex flex-col justify-center items-center">
                        <h3 className="mt-2 font-semibold">Taskwhiz Business</h3>
                        <h3 className="mt-2 font-semibold">Teach On Taskwhiz</h3>
                        <h3 className="mt-2 font-semibold">Get the App</h3>
                        <h3 className="mt-2 font-semibold">About Us</h3>
                        <h3 className="mt-2 font-semibold">Contact Us</h3>
                    </div>
                    <div className="flex flex-col justify-center items-center">
                        <h3 className="mt-2 font-semibold">Careers</h3>
                        <h3 className="mt-2 font-semibold">Blog</h3>
                        <h3 className="mt-2 font-semibold">Help and Support</h3>
                        <h3 className="mt-2 font-semibold">Affiliate</h3>
                        <h3 className="mt-2 font-semibold">Investors</h3>
                    </div>
                </div>
                <div>
                    <h2 className="text-7xl font-bold text-blue-700">TaskWhiz</h2>
                </div>
            </div>
        </div>
    )
}

export default Home;


