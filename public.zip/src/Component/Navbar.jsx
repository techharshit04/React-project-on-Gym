// // by useContext   ,   28 aug 


import React, { useState } from "react";
import { NavLink, useNavigate, Navigate } from "react-router-dom";
function Navbar() {
    let nav = useNavigate();
    let [count, setcount] = useState(0)
    let handleclick = () => {
        alert("Please Login first to access Dashboard")
    }
    return (
        <div className='bg-blue-200 fixed z-10 h-22 text-black flex w-full items-center justify-around p-4 text-lg'>

            <div>
                <h2 className=" italic text-3xl text-blue-700 text-2xl font-bold">Task-Whiz</h2>
            </div>
            {count == 5 && <Navigate to="/" />}
            <div className="w-90 flex justify-between">
                <NavLink to="/" >Home</NavLink>
                <NavLink to="/dashboard/dashcopy"  >Dashboard</NavLink>
                <NavLink to="/about" >About</NavLink>
                <NavLink to="/contact" >Contact</NavLink>
            </div>
            <div>
                <NavLink to="/login" className="pr-4 pl-4 bg-blue-800 text-white p-2 rounded" >Login <i class="fa-solid fa-user"></i></NavLink>
            </div>

        </div>
    )
}

export default Navbar;