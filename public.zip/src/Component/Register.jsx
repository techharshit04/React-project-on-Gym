import { NavLink } from "react-router-dom"

function Register() {
    return (
        <div className="w-full flex justify-center">
            <div className="w-320 flex justify-between mt-30">
                <div className="bg-blue-400">
                    <img src="/pic6.png" alt="" className="w-150 mt-10" />
                </div>
                <div className="w-210 bg-blue-200 flex flex-col items-start justify-center p-10">
                    <h2 className="text-4xl text-blue-700 font-bold">Sign up</h2>
                    <div className="w-full mt-10">
                        <h5 className="font-bold">Email</h5>
                        <input type="text" placeholder="Enter email" className=" border-2 rounded w-full mt-1 p-2" />
                    </div>
                    <div className="w-full mt-7">
                        <h5 className="font-bold">Password</h5>
                        <input type="text" placeholder="Enter Password" className=" border-2 rounded w-full mt-1 p-2" />
                    </div>
                      <div className="w-full mt-7">
                        <h5 className="font-bold">Confirm Password</h5>
                        <input type="text" placeholder="Confirm your Password" className=" border-2 rounded w-full mt-1 p-2" />
                    </div>
                    <h5 className="mt-5 text-lg">Already have an account ? <NavLink to="/login"><span className="underline text-blue-500">Login Here</span></NavLink> </h5>
                    <button className="bg-blue-900 rounded p-1 w-30 mt-6 text-white text-lg font-semibold" onClick={() => {
                        localStorage.setItem("loggedin", true)
                    }}>Sign up</button>
                </div>
            </div>
        </div>
    )
}

export default Register;