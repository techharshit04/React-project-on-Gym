// main


// function Temp({ detail , image }) {
//     return (
//         <div className="box">
//             <div className="product_image">
//                 <div className="prdt_image">
//                     <img src={image.shoe} alt="item" className="prdt_img" />
//                 </div>
//                 <div className="prdt_size">
//                     <h3>CHOOSE SIZE</h3>
//                     <div>
//                         <h4>6</h4>
//                         <h4>7</h4>
//                         <h4>8</h4>
//                         <h4>9</h4>
//                         <h4>10</h4>
//                         <h4>11</h4>
//                         <h4>12</h4>

//                     </div>
//                 </div>
//             </div>
//             <div className="about_product">
//                 <h2>ON SALE</h2>
//                 <h3 style={{textDecoration:"underline"}}>{detail.name}</h3>
//                 <div className="price">
//                     <del style={{ color: "rgba(255, 0, 0, 1)"}}>{detail.mrp}</del>
//                     <h2 style={{ color: "black" }}>{detail.price}</h2>
//                 </div>
//                 <h5 className="about_item">{detail.about_item}</h5>
//                 <div className="color_choice">
//                     <h5>Red</h5>
//                     <h5>White</h5>
//                     <h5>Black</h5>
//                 </div>
//                 <button>Add to Cart</button>
//             </div>
//         </div>
//     )
// }
// export default Temp;






// by prompt  1



function Temp({ name, mrp, price, about_item, shoe }) {
    return (
        <div className="maina">
            <div className="box">
                <div className="product_image">
                    <div className="prdt_image">
                        <img src={shoe} alt="item" className="prdt_img" />
                    </div>
                    <div className="prdt_size">
                        <h3>CHOOSE SIZE</h3>
                        <div>
                            <h4>6</h4>
                            <h4>7</h4>
                            <h4>8</h4>
                            <h4>9</h4>
                            <h4>10</h4>
                            <h4>11</h4>
                            <h4>12</h4>

                        </div>
                    </div>
                </div>
                <div className="about_product">
                    <h2>ON SALE</h2>
                    <h3 style={{ textDecoration: "underline" }}>{name}</h3>
                    <div className="price">
                        <del style={{ color: "rgba(255, 0, 0, 1)" }}>${mrp}</del>
                        <h2 style={{ color: "black" }}>${price}</h2>
                    </div>
                    <h5 className="about_item">{about_item}</h5>
                    <div className="color_choice">
                        <h5>Red</h5>
                        <h5>White</h5>
                        <h5>Black</h5>
                    </div>
                    <button>Add to Cart</button>
                </div>
            </div>
        </div>
    )
}
export default Temp;




// // by sir form 



// import React from 'react'

// export default function Temp({ name, mrp, price, about, url }) {
//     return (
//         // <div className='product-card' >

//         //     <p className='title'>Name :-  {name}</p>
//         //     <p className='title'>MRP :-  {mrp}</p>
//         //     <p className='title'>Price :-  {price}</p>
//         //     <p className='title'>About :-  {about}</p>
//         //     <p className='title'>URL :- {url}</p>
//         //     <button>show details</button>
//         // </div>




//         <div className="maina">
//             <div className="box">
//                 <div className="product_image">
//                     <div className="prdt_image">
//                         <img src={url} alt="item" className="prdt_img" />
//                     </div>
//                     <div className="prdt_size">
//                         <h3>CHOOSE SIZE</h3>
//                         <div>
//                             <h4>6</h4>
//                             <h4>7</h4>
//                             <h4>8</h4>
//                             <h4>9</h4>
//                             <h4>10</h4>
//                             <h4>11</h4>
//                             <h4>12</h4>

//                         </div>
//                     </div>
//                 </div>
//                 <div className="about_product">
//                     <h2>ON SALE</h2>
//                     <h3 style={{ textDecoration: "underline" }}>{name}</h3>
//                     <div className="price">
//                         <del style={{ color: "rgba(255, 0, 0, 1)" }}>${mrp}</del>
//                         <h2 style={{ color: "black" }}>${price}</h2>
//                     </div>
//                     <h5 className="about_item">{about}</h5>
//                     <div className="color_choice">
//                         <h5>Red</h5>
//                         <h5>White</h5>
//                         <h5>Black</h5>
//                     </div>
//                 </div>
//             </div>
//             <div className="add_button">
//                 <button>Add to Cart</button>
//             </div>
//         </div>
//     )
// } 