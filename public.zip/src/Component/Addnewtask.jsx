
// // task 28 aug    ,   by context


import React, { useContext, useState } from 'react'
import { taskcontext } from '../App';

export default function Addtask() {
    let { addtask } = useContext(taskcontext)
    let [title, settitle] = useState("")
    let [description, setdescription] = useState("");
    let [startdate, setstartdate] = useState("")
    let [enddate, setenddate] = useState("");
    let [status, setstatus] = useState("")
    let [priority, setpriority] = useState("");
    let submithandler = (e) => {
        e.preventDefault();
        addtask({ title, description, startdate, enddate, status, priority })
    }
    return (
        <>
            <div className="w-320 ml-50 mt-7 text-black h-full flex flex-col justify-center items-center">
                <h2 className="text-2xl font-semibold mb-7">Add Task</h2>
                <form className="w-120" onSubmit={submithandler}>
                    <div className="flex flex-col mb-5">
                        <label htmlFor="name" className="font-semibold">TITLE</label>
                        <input type="text" placeholder="Enter Task" className=" rounded mt-2 h-10 p-3 bg-slate-200" value={title} onChange={(e) => { settitle(e.target.value) }} />
                    </div>

                    <div className="flex flex-col mb-5">
                        <label htmlFor="name" className="font-semibold">DESCRIPTION</label>
                        <textarea className=" rounded mt-2 h-30 p-3 bg-slate-200" placeholder="Task Description" value={description} onChange={(e) => { setdescription(e.target.value) }}></textarea>
                    </div>

                    <div className="flex justify-between mt-3">
                        <div className="flex flex-col">
                            <label htmlFor="START TASK">START TASK</label>
                            <input type="date" className=" rounded h-10 mt-2 p-1 bg-slate-200" value={startdate} onChange={(e) => { setstartdate(e.target.value) }} />
                        </div>
                        <div className="flex flex-col">
                            <label htmlFor="END TASK">END TASK</label>
                            <input type="date" className="rounded h-10 mt-2 p-1 bg-slate-200" value={enddate} onChange={(e) => { setenddate(e.target.value) }} />
                        </div>
                    </div>

                    <div className="w-full flex justify-between mt-5">
                        <div className="flex flex-col">
                            <label htmlFor="status">STATUS</label>
                            <select id="task" className="w-25 mt-2 p-2 bg-slate-200 rounded" value={status} onChange={(e) => { setstatus(e.target.value) }}>
                                <option value="Compelete" onChange={(e) => { setstatus(e.target.value) }}>Compelete</option>
                                <option value="Pending">Pending</option>
                                <option value="Progress">Progress</option>
                                <option value="Deployed">Deployed</option>
                                <option value="Deferred">Deferred</option>
                            </select>
                        </div>
                        <div className="flex flex-col">
                            <label htmlFor="priority">PRIORITY</label>
                            <select id="Priority" className="w-15 mt-2 p-2 bg-slate-200 rounded" value={priority} onChange={(e) => { setpriority(e.target.value) }}>
                                <option value="P0">P0</option>
                                <option value="P1">P1</option>
                                <option value="P2">P2</option>
                                <option value="P3">P3</option>
                            </select>
                        </div>
                    </div>
                    <div>
                        <button className="border w-120 rounded text-white bg-blue-800 h-10 mt-8">ADD Task</button>
                    </div>
                </form>
            </div>
        </>
    )
}


















// export default function Addnewtask() {
//     return (
//         <>
//             <div className="w-[150vh] text-black h-full flex flex-col justify-center items-center">
//                 <h2 className="text-2xl font-semibold mb-7">Add Task</h2>
//                 <div className="w-120">
//                     <div className="flex flex-col mb-5">
//                         <label htmlFor="name" className="font-semibold">TITLE</label>
//                         <input type="text" placeholder="Enter Task" className=" rounded mt-2 h-10 p-3 bg-slate-200" />
//                     </div>

//                     <div className="flex flex-col mb-5">
//                         <label htmlFor="name" className="font-semibold">DESCRIPTION</label>
//                         <textarea className=" rounded mt-2 h-30 p-3 bg-slate-200" placeholder="Task Description"></textarea>
//                     </div>

//                     <div className="flex justify-between mt-3">
//                         <div className="flex flex-col">
//                             <label htmlFor="START TASK">START TASK</label>
//                             <input type="date" className=" rounded h-10 mt-2 p-1 bg-slate-200" />
//                         </div>
//                         <div className="flex flex-col">
//                             <label htmlFor="END TASK">END TASK</label>
//                             <input type="date" className="rounded h-10 mt-2 p-1 bg-slate-200" />
//                         </div>
//                     </div>

//                     <div className="w-full flex justify-between mt-5">
//                         <div className="flex flex-col">
//                             <label htmlFor="status">STATUS</label>
//                             <select id="task" className="w-25 mt-2 p-2 bg-slate-200 rounded">
//                                 <option value="Compelete">Compelete</option>
//                                 <option value="Pending">Pending</option>
//                                 <option value="Progress">Progress</option>
//                                 <option value="Deployed">Deployed</option>
//                                 <option value="Deferred">Deferred</option>
//                             </select>
//                         </div>
//                         <div className="flex flex-col">
//                             <label htmlFor="priority">PRIORITY</label>
//                             <select id="Priority" className="w-15 mt-2 p-2 bg-slate-200 rounded">
//                                 <option value="P0">P0</option>
//                                 <option value="P1">P1</option>
//                                 <option value="P2">P2</option>
//                             </select>
//                         </div>
//                     </div>

//                 </div>
//                 <div>
//                     <button className="border w-120 rounded text-white bg-blue-800 h-10 mt-8">ADD Task</button>
//                 </div>
//             </div>

//         </>
//     )
// }

