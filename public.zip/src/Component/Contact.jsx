function Contact() {
    return (
        <div className="w-full flex justify-center">
            <div className="w-200 p-20 flex flex-col justify-center items-center bg-slate-50 mt-20">
                <h2 className="text-4xl font-semibold">Contact Me</h2>
                <div className="flex flex-col justify-center items-center mt-5">
                    <h5>We’d love to hear from you! Whether you have questions, feedback,</h5>
                    <h5>or need assistance, feel free to reach out. Our team is here to help and will get back to you</h5>
                    <h5>as soon as possible. Let’s stay connected!</h5>
                </div>
                <div className="w-full mt-10">
                    <h5 className="font-bold">Name</h5>
                    <input type="text" placeholder="Enter your Name" className=" bg-gray-600 text-white border-2 w-full mt-1 p-2" />
                </div>
                <div className="w-full mt-10">
                    <h5 className="font-bold">Email</h5>
                    <input type="text" placeholder="name@gmail.com" className=" bg-gray-600 text-white border-2 w-full mt-1 p-2" />
                </div>
                <div className="w-full mt-10">
                    <h5 className="font-bold">Mobile</h5>
                    <input type="text" placeholder="Enter your number" className=" bg-gray-600 text-white border-2 w-full mt-1 p-2" />
                </div>
                <div className="w-full mt-10">
                    <h5 className="font-bold">Subject</h5>
                    <input type="text" placeholder="Let us know how we can help you" className=" bg-gray-600 text-white border-2 w-full mt-1 p-2" />
                </div>
                <div className="w-full mt-10">
                    <h5 className="font-bold">Message</h5>
                    <input type="text" placeholder="Leave a message" className=" bg-gray-600 text-white border-2 w-full mt-1 p-2 pb-25" />
                </div>
                <button className="mt-7 bg-gray-600 p-2 w-40 text-white">Send Message</button>
            </div>
        </div>
    )
}

export default Contact;