// // // by useContext   ,   28 aug 

import { NavLink } from "react-router-dom";
import React, { useContext } from 'react'
import { taskcontext } from '../App';

export default function Taskstatus() {
    let { todos } = useContext(taskcontext)

    return (
        <div className="w-300 ml-30 text-black mt-7 flex flex-col justify-center items-center">
            <div>
                <h2 className="w-[155vh] text-black h-10 flex justify-center items-center text-4xl mt-5 font-bold ">Task Status</h2>
            </div>
            <div className="h-[60vh] text-black w-[80vh] flex flex-col flex-wrap gap-5 ml-20 mt-20">
                <div className="w-80 h-50 flex justify-between items-center p-6 inset-shadow-sm inset-shadow-orange-500 rounded">
                    <div>
                        <h2 className="text-xl mb-3 font-semibold">TOTAL Task</h2>
                        <h3 className="text-3xl font-semibold mb-3">{todos.filter((a) => { return a.status }).length}</h3>
                        <span>110 last month</span>
                    </div>
                    <div>
                        <h2 className="font-extrabold text-5xl p-1 text-blue-700 p-3 rounded-xl bg-yellow-400">T</h2>
                    </div>
                </div>
                <div className="w-80 h-50 flex justify-between items-center p-6 inset-shadow-sm inset-shadow-teal-500 rounded">
                    <div>
                        <h2 className="text-xl mb-3 font-semibold">Pending Task</h2>
                        <h3 className="text-3xl font-semibold mb-3">{todos.filter((a) => { return a.status == "Pending" }).length}</h3>
                        <span>110 last month</span>
                    </div>
                    <div>
                        <h2 className="font-extrabold text-5xl p-1 text-blue-700 p-3 rounded-xl bg-lime-400">P</h2>
                    </div>
                </div>
                <div className="w-80 h-50 flex justify-between items-center p-6 inset-shadow-sm inset-shadow-green-500 rounded">
                    <div>
                        <h2 className="text-xl mb-3 font-semibold">Progress Task</h2>
                        <h3 className="text-3xl font-semibold mb-3">{todos.filter((a) => { return a.status == "Progress" }).length}</h3>
                        <span>110 last month</span>
                    </div>
                    <div>
                        <h2 className="font-extrabold text-5xl p-1 text-blue-700 p-3 rounded-xl bg-teal-400">P</h2>
                    </div>
                </div>
                <div className="w-80 h-50 flex justify-between items-center p-6 inset-shadow-sm inset-shadow-pink-500  rounded">
                    <div>
                        <h2 className="text-xl mb-3 font-semibold">Completed Task</h2>
                        <h3 className="text-3xl font-semibold mb-3">{todos.filter((a) => { return a.status == "Compelete" }).length}</h3>
                        <span>110 last month</span>
                    </div>
                    <div>
                        <h2 className="font-extrabold text-5xl p-1 text-blue-700 p-3 rounded-xl bg-fuchsia-400">C</h2>
                    </div>
                </div>
                <div className="w-80 h-50 flex justify-between items-center p-6 inset-shadow-sm inset-shadow-purple-500 rounded">
                    <div>
                        <h2 className="text-xl mb-3 font-semibold">Deployed Task</h2>
                        <h3 className="text-3xl font-semibold mb-3">{todos.filter((a) => { return a.status == "Deployed" }).length}</h3>
                        <span>110 last month</span>
                    </div>
                    <div>
                        <h2 className="font-extrabold text-5xl p-1 text-blue-700 p-3 rounded-xl bg-purple-400">D</h2>
                    </div>
                </div>
                <div className="w-80 h-50 flex justify-between items-center p-6 inset-shadow-sm inset-shadow-sky-500 rounded">
                    <div>
                        <h2 className="text-xl mb-3 font-semibold">Deferred Task</h2>
                        <h3 className="text-3xl font-semibold mb-3">{todos.filter((a) => { return a.status == "Deferred" }).length}</h3>
                        <span>110 last month</span>
                    </div>
                    <div>
                        <h2 className="font-extrabold text-5xl p-3 text-blue-700 p-3 rounded-xl bg-cyan-400">D</h2>
                    </div>
                </div>
            </div>
        </div>
    )
}
