import { NavLink } from "react-router-dom"

export default function Login() {
    return (
        <div className="w-full flex justify-center">
            <div className="w-320 flex justify-between mt-35">
                <div className="bg-blue-400">
                    <img src="/pic5.png" alt="" className="w-150 h-120"/>
                </div>
                <div className="w-210 bg-blue-200 flex flex-col items-start justify-center p-20">
                    <h2 className="text-4xl text-blue-700 font-bold">Login</h2>
                    <div className="w-full mt-10">
                        <h5 className="font-bold">Email</h5>
                        <input type="text" placeholder="Enter email" className=" border-2 rounded w-full mt-1 p-2" />
                    </div>
                    <div className="w-full mt-10">
                        <h5 className="font-bold">Password</h5>
                        <input type="text" placeholder="Enter Password" className=" border-2 rounded w-full mt-1 p-2" />
                    </div>
                    <h5 className="mt-5 text-lg">New User ? <NavLink to="/register"><span className="underline text-blue-500">Register Here</span></NavLink></h5>
                    <button className="bg-blue-900 rounded p-1 w-30 mt-6 text-white text-lg font-semibold" onClick={() => {
                        localStorage.setItem("loggedin", true)
                    }}>Login</button>
                </div>
            </div>
        </div>
    )
}